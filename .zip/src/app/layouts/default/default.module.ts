import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DefaultComponent } from './default.component';
import { HomeComponent } from 'src/app/modules/home/home.component';
import { PostComponent } from 'src/app/modules/post/post.component';
import { RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CreateProjectComponent } from 'src/app/modules/projects/create-project/create-project.component';
import { ProjectDetailsComponent } from 'src/app/modules/projects/project-details/project-details.component';



@NgModule({
  declarations: [
    DefaultComponent,
    HomeComponent,
    PostComponent,
    ProjectDetailsComponent, 
    CreateProjectComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    SharedModule,
    FlexLayoutModule
  ]
})
export class DefaultModule { }
